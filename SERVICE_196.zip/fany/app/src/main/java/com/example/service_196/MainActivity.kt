package com.example.service_196

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.net.Uri
import android.content.Intent
import android.media.MediaPlayer
import  kotlinx.android.synthetic.main.activity_main.*



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //btn facebook
        btn_facebook.setOnClickListener({

            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com/langitinspirasi"))
            startActivity(i)
        })

        //btn instagram
        btn_instagram.setOnClickListener({

            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.instagram.co.id/langitinspirasi"))
            startActivity(i)
        })

        //mp3 player

        var MediaPlayer : MediaPlayer? = MediaPlayer.create(this,R.raw.everlong)

        //btn_play
        btn_play.setOnClickListener {
             MediaPlayer?.
        }

        //btn_pause
        btn_pause.setOnClickListener {
            MediaPlayer?.pause()
        }  0

        //btn_stop
        btn_stop.setOnClickListener {
            MediaPlayer?.pause()
            MediaPlayer?.seekTo(0)
        }
    }
}
