package com.example.service196

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //button facebook
        btn_facebook.setOnClickListener({
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com/langitinspisari"))
            startActivity(i) })

        //button instagram
        btn_instagram.setOnClickListener({
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.instagram.com/langitinspisari.co.id"))
            startActivity(i) })

        var MediaPlayer : MediaPlayer? = MediaPlayer.create(this, R.raw.dj2019)

        //btn play
        btn_play.setOnClickListener{
            MediaPlayer?.start()
        }

        //btn pause
        btn_pause.setOnClickListener{
            MediaPlayer?.pause()
        }
        //btn stop
        btn_stop.setOnClickListener{
            MediaPlayer?.pause()
            MediaPlayer?.seekTo(0)
        }
    }
}
